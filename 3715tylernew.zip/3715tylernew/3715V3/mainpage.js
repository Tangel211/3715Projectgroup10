/**
 * 
 */
function saveEdits(){
	var editElem=document.getElementById("events");
	
	var userVersion = editElem.innerHTML;
	
	localStorage.userEdits = userVersion;
	
	document.getElementById("update").innerHTML="Edits Saved";
}

function saveEdits2() {
	var editElem2=document.getElementById("campuses");
	
	var userVersion2 = editElem2.innerHTML;
	
	localStorage.userEdits2 = userVersion2;
}

function checkEdits(){
	if(localStorage.userEdits!=null)
		document.getElementById("events").innerHTML=localStorage.userEdits;
	if(localStorage.userEdits2!=null)
		document.getElementById("campuses").innerHTML=localStorage.userEdits2;
	
}

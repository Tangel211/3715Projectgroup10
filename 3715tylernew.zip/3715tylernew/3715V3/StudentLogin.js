/**
 * http://usejsdoc.org/
 */


function checkLog(){
	var sNumber=document.getElementById("Student Number").value;
	var pWord= document.getElementById("password").value;
	if(sNumber == "201353257" && pWord== "12345"){
		
		
			window.location.href="Students.html";
		
	}
	else{
		alert("invalid username");
	}
}
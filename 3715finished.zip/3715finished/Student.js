/**
 * 
 */




function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
	
 var coursename=document.getElementById("coursename_row"+no);
 var coursenumber=document.getElementById("coursenumber_row"+no);
 
	
 var coursename_data=coursename.innerHTML;
 var coursenumber_data=coursenumber.innerHTML;
 
	
 coursename.innerHTML="<input type='text' id='coursename_text"+no+"' value='"+coursename_data+"'>";
 coursenumber.innerHTML="<input type='text' id='coursenumber_text"+no+"' value='"+coursenumber_data+"'>";
 
 
}

function save_row(no)
{
 var coursename_val=document.getElementById("coursename_text"+no).value;
 var coursenumber_val=document.getElementById("coursenumber_text"+no).value;
 

 document.getElementById("coursename_row"+no).innerHTML=coursename_val;
 document.getElementById("coursenumber_row"+no).innerHTML=coursenumber_val;
 

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
 
 var editTab=document.getElementById("wrapper");
	
 var userCourses = editTab.innerHTML;
	
 localStorage.userCourses = userCourses;
}

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
 
 var editTab=document.getElementById("wrapper");
	
 var userCourses = editTab.innerHTML;
	
 localStorage.userCourses = userCourses;
}

function add_row()
{
 var new_coursename=document.getElementById("new_coursename").value;
 var new_coursenumber=document.getElementById("new_coursenumber").value;

	
 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='coursename_row"+table_len+"'>"+new_coursename+"</td><td id='coursenumber_row"+table_len+"'>"+new_coursenumber+"</td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='edit' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'> <input type='button' value='Delete' class='delete' onclick='delete_row("+table_len+")'></td></tr>";

 document.getElementById("new_coursename").value="";
 document.getElementById("new_coursenumber").value="";
 
 var editTab=document.getElementById("wrapper");
	
 var userCourses = editTab.innerHTML;
	
 localStorage.userCourses = userCourses;
	
 document.getElementById("update").innerHTML="Edits Saved";
 
}

function checkCourses(){
	
	if(localStorage.userCourses!=null)
		document.getElementById("wrapper").innerHTML=localStorage.userCourses;
	
}

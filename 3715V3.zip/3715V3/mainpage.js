/**
 * 
 */
var express=require("express"),
	app =express(),
	http= require("http").Server(app).listen(3340)
	
app.use("/", express.static("."))
app.use("/", express.static("."))
app.use("/", express.static("."))

console.log("Server started at port 3340")
app.get("/",function(req,res){
	res.sendFile(__dirname +"/MainPage.html");
})


function saveEdits(){
	var editElem=document.getElementById("events");
	
	var userVersion = editElem.innerHTML;
	
	localStorage.userEdits = userVersion;
	
	document.getElementById("update").innerHTML="Edits Saved";
}

function saveEdits2() {
	var editElem2=document.getElementById("campuses");
	
	var userVersion2 = editElem2.innerHTML;
	
	localStorage.userEdits2 = userVersion2;
}

function checkEdits(){
	if(localStorage.userEdits!=null)
		document.getElementById("events").innerHTML=localStorage.userEdits;
	if(localStorage.userEdits2!=null)
		document.getElementById("campuses").innerHTML=localStorage.userEdits2;
	
}
